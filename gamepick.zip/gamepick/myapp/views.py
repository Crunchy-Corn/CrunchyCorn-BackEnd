from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Game


class RecommendAPI(APIView):
    def get_genre_recommendation(self, favorite_games):
        favorite_genres = {}

        # 사용자가 좋아하는 게임들의 장르 선호도 계산
        for game in favorite_games:
            if game.genre in favorite_genres:
                favorite_genres[game.genre] += 1
            else:
                favorite_genres[game.genre] = 1

        # 장르 선호도 중 가장 높은 장르 찾기
        recommended_genre = max(favorite_genres, key=favorite_genres.get)
        return recommended_genre

    def get(self, request):
        # 간단한 형태로 선호하는 게임들의 ID 리스트를 입력받음
        favorite_game_ids = request.GET.getlist('favorite_games[]', [])

        # 입력받은 게임 ID 리스트를 사용하여 게임 정보를 가져옴
        favorite_games = Game.objects.filter(pk__in=favorite_game_ids)

        # 선호하는 게임의 장르 추천
        recommended_genre = self.get_genre_recommendation(favorite_games)

        # 추천 결과 반환
        return Response({'recommended_genre': recommended_genre})
