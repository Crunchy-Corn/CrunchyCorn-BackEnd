from django.db import models

class Game(models.Model):
    id = models.AutoField(primary_key=True)
    image = models.ImageField()
    title = models.CharField(max_length=100)
    genre = models.CharField(max_length=50)

    def __str__(self):
        return self.title

class Preference(models.Model):
    favorite_games = models.ManyToManyField(Game)

    def __str__(self):
        return f'Preference {self.pk}'

class Mode(models.Model):
    MODE_CHOICES = [
        ('solo', '혼자'),
        ('multiplayer', '멀티'),
    ]
    preference = models.OneToOneField(Preference, on_delete=models.CASCADE, related_name='mode')
    preferred_mode = models.CharField(choices=MODE_CHOICES, max_length=20)

    def __str__(self):
        return f'{self.get_preferred_mode_display()} Mode for Preference {self.preference.pk}'

class TimePreference(models.Model):
    TIME_CHOICES = [
        ('1', '10분 미만'),
        ('2', '11~20분'),
        ('3', '21~30분'),
        ('4', '30분 이상'),
    ]
    preference = models.OneToOneField(Preference, on_delete=models.CASCADE, related_name='time_preference')
    preferred_time = models.CharField(choices=TIME_CHOICES, max_length=20)

    def __str__(self):
        return f'{self.get_preferred_time_display()} Time Preference for Preference {self.preference.pk}'
