from rest_framework import serializers
from .models import Preference, Mode, TimePreference

class PreferenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Preference
        fields = '__all__'

class ModeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mode
        fields = '__all__'

class TimePreferenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = TimePreference
        fields = '__all__'
